# CineFlix Store

Plataforma de películas digitales con carrito de compras, pago simulado y factura electrónica.

## Tecnologías

- Frontend: React + Vite
- Backend: Java 17 + Spring Boot + Spring Data JPA
- Base de datos: MySQL

## Funciones incluidas

- Catálogo de películas, series, documentales, cortometrajes y premium.
- Carruseles por categoría/género.
- Búsqueda por título, género, año, director y actor principal.
- Carrito flotante.
- Agregar productos, eliminar productos y actualizar cantidades.
- Si se agrega la misma película con el mismo tipo de compra/renta, solo aumenta cantidad.
- Checkout con forma de pago.
- Generación automática de factura electrónica simple.
- Biblioteca personal del usuario.
- Favoritos.
- Reseñas y calificaciones.
- Panel administrador con estadísticas básicas.

## Requisitos

- Java 17 o superior.
- Maven.
- Node.js 18 o superior.
- MySQL 8 o superior.

## 1. Crear base de datos

En MySQL ejecuta:

```sql
CREATE DATABASE cineflix_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

O usa el archivo:

```txt
database/create_database.sql
```

## 2. Configurar backend

Edita:

```txt
backend/cineflix-api/src/main/resources/application.properties
```

Configura las variables de entorno DB_USERNAME y DB_PASSWORD antes de iniciar el backend:

```properties
DB_USERNAME=root
DB_PASSWORD=TU_PASSWORD
```

## 3. Ejecutar backend

```bash
cd backend/cineflix-api
mvn spring-boot:run
```

La API inicia en:

```txt
http://localhost:8080/api
```

## 4. Ejecutar frontend

```bash
cd frontend/cineflix-react
npm install
npm run dev
```

El frontend inicia en:

```txt
http://localhost:5173
```

## Usuario demo

El sistema crea automáticamente un usuario demo:

```txt
ID: 1
Nombre: Cliente Demo
Correo: cliente@cineflix.com
```

El frontend usa este usuario por defecto para carrito, favoritos, reseñas, pedidos y biblioteca.

## Endpoints principales

```txt
GET    /api/peliculas
GET    /api/peliculas/{id}
GET    /api/peliculas/buscar?q=texto
POST   /api/carrito/agregar
GET    /api/carrito/{usuarioId}
PUT    /api/carrito/cantidad
DELETE /api/carrito/item/{itemId}
DELETE /api/carrito/vaciar/{usuarioId}
POST   /api/pedidos/checkout
GET    /api/facturas/pedido/{pedidoId}
POST   /api/resenas
GET    /api/biblioteca/{usuarioId}
GET    /api/admin/estadisticas
```

## Nota sobre imágenes

Los pósters son SVG propios de demostración ubicados en:

```txt
frontend/cineflix-react/public/posters
```

Puedes reemplazarlos por pósters reales respetando derechos de uso.
